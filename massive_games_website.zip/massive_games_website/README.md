# Massive Games website

This is the actual responsive website, not a screenshot.

## Thumbnails
All five original thumbnails supplied by the user are embedded directly inside `index.html`, so the images display even if the HTML file is opened by itself. Separate thumbnail files are also included for convenience.

## Projects
- Survive The Backrooms — IN DEVELOPMENT
- Burger Stand — IN DEVELOPMENT
- Saitama Battle — IN DEVELOPMENT
- Last Target — IN DEVELOPMENT
- INFECT — IN DEVELOPMENT

All projects are owned by Massive Games Studio.

For online publishing, upload `index.html` to a web host. The image thumbnails are embedded, so no separate image upload is needed for them. Add Roblox game URLs when the games are published.
